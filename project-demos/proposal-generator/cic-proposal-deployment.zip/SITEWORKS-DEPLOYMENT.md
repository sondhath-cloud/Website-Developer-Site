# 🚀 SiteWorks Deployment Guide for CIC Proposal Generator

## **What You Need to Deploy**

**DO NOT just upload HTML/CSS files!** You need to deploy the **entire Node.js application** including:
- ✅ `server.js` (Node.js backend)
- ✅ `package.json` (dependencies)
- ✅ `app.js` (frontend JavaScript)
- ✅ `index.html` (main form)
- ✅ `styles.css` (styling)
- ✅ `template.docx` (document template)
- ✅ `siteworks.json` (SiteWorks config)

## **Step-by-Step SiteWorks Deployment**

### **Step 1: Create Node.js Application in SiteWorks**

1. **Log into SiteWorks Dashboard**
2. **Click "Create New Application"**
3. **Select "Node.js"** as the application type
4. **Choose your domain** (e.g., `yourdomain.com` or subdomain)
5. **Set Node.js version** to **14.x or higher**

### **Step 2: Upload Your Project Files**

**Method A: Git Repository (Recommended)**
1. **Push your project to GitHub/GitLab**
2. **In SiteWorks, connect your Git repository**
3. **Set build command**: `npm install`
4. **Set start command**: `npm start`

**Method B: Direct File Upload**
1. **Zip your entire project folder** (including all files above)
2. **Upload the ZIP file** to SiteWorks
3. **Extract the files** in the root directory

### **Step 3: Configure Environment Variables**

In SiteWorks dashboard, set these environment variables:
```
NODE_ENV=production
PORT=3000 (or whatever SiteWorks assigns)
```

### **Step 4: Set Build and Start Commands**

**Build Command:**
```bash
npm install
```

**Start Command:**
```bash
npm start
```

### **Step 5: Deploy and Test**

1. **Click "Deploy"** in SiteWorks
2. **Wait for build to complete** (usually 2-5 minutes)
3. **Test your application** at your domain

## **File Structure on SiteWorks**

Your deployed application should look like this:
```
/
├── server.js          ← Main server file
├── package.json       ← Dependencies
├── siteworks.json     ← SiteWorks config
├── app.js            ← Frontend JavaScript
├── index.html        ← Main form
├── styles.css        ← Styling
├── template.docx     ← Document template
├── form-data.json    ← Data storage (auto-created)
└── node_modules/     ← Dependencies (auto-created)
```

## **Important SiteWorks Considerations**

### **Port Configuration**
- SiteWorks will assign a port automatically
- The server will use `process.env.PORT` from SiteWorks
- No need to change the code

### **Data Persistence**
- `form-data.json` will be created automatically
- Data persists between deployments
- Multiple users can access simultaneously

### **Domain Access**
- Your form will be available at: `https://yourdomain.com`
- API endpoints: `https://yourdomain.com/api/*`
- All themes and functionality will work

## **Troubleshooting Common Issues**

### **Build Fails**
- Check Node.js version (must be 14+)
- Verify `package.json` has correct dependencies
- Check build logs in SiteWorks dashboard

### **App Won't Start**
- Verify start command is `npm start`
- Check environment variables
- Review error logs in SiteWorks

### **Form Not Loading**
- Ensure all files uploaded (especially `index.html`)
- Check if `server.js` is in root directory
- Verify API endpoints are accessible

## **Testing Multi-User Persistence**

After deployment:
1. **Open your form** at `https://yourdomain.com`
2. **Add a custom jurisdiction** (e.g., "Township")
3. **Open in different browser/incognito** → Should see the new option
4. **Test from different computer** → Data should persist

## **Maintenance and Updates**

### **Updating the Application**
1. **Make changes locally**
2. **Push to Git** (if using Git deployment)
3. **Redeploy in SiteWorks**

### **Backing Up Data**
- `form-data.json` contains all user additions
- Download this file periodically for backup
- SiteWorks may also have backup options

## **Support**

If you encounter issues:
1. **Check SiteWorks build logs**
2. **Verify all files are uploaded**
3. **Test locally first** with `node server.js`
4. **Contact SiteWorks support** for hosting issues

## **Final Checklist**

Before deploying, ensure you have:
- [ ] `server.js` (Node.js backend)
- [ ] `package.json` (with all dependencies)
- [ ] `siteworks.json` (SiteWorks configuration)
- [ ] `app.js` (frontend JavaScript)
- [ ] `index.html` (main form)
- [ ] `styles.css` (styling)
- [ ] `template.docx` (document template)
- [ ] **NOT just HTML/CSS files alone**

**Remember: This is a full-stack Node.js application that needs the backend server to function!**









